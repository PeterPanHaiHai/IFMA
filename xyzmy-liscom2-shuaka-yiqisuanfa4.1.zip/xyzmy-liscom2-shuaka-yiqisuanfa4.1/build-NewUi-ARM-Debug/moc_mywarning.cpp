/****************************************************************************
** Meta object code from reading C++ file 'mywarning.h'
**
** Created: Fri Dec 18 12:04:03 2015
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../working/mywarning.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mywarning.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_Mywarning[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      11,   10,   10,   10, 0x05,

 // slots: signature, parameters, type, tag, flags
      25,   10,   10,   10, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_Mywarning[] = {
    "Mywarning\0\0Pressed_Yes()\0send_yesSignal()\0"
};

const QMetaObject Mywarning::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Mywarning,
      qt_meta_data_Mywarning, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &Mywarning::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *Mywarning::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *Mywarning::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Mywarning))
        return static_cast<void*>(const_cast< Mywarning*>(this));
    return QDialog::qt_metacast(_clname);
}

int Mywarning::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: Pressed_Yes(); break;
        case 1: send_yesSignal(); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void Mywarning::Pressed_Yes()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
