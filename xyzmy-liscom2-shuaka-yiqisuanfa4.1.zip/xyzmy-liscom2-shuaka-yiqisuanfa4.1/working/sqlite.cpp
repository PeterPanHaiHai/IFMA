#include "sqlite.h"

SQL *SQLITE::sql=new SQL();
