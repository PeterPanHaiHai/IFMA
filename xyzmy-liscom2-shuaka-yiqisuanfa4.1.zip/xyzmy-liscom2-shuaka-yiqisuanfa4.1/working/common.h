//common.h just save the data of the MyIputUsername,such as User1...
#ifndef COMMON_H
#define COMMON_H
#include <QString>

extern QString *MyInputUsername;
#endif // COMMON_H
