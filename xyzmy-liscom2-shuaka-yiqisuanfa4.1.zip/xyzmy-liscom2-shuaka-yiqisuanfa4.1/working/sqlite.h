#ifndef SQLITE_H
#define SQLITE_H
#include "sql.h"

class SQLITE
{
public:
    static SQL *sql;
};

#endif // SQLITE_H
